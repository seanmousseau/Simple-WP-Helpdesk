<?php
/**
 * Global helpers: defaults, statuses, anti-spam, rate limiting, and ticket link utilities.
 *
 * @package Simple_WP_Helpdesk
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Returns the plugin's complete default option values.
 *
 * Result is cached per request via a static variable to avoid repeated calls.
 *
 * @return array<string, mixed> Associative array of option keys to their default values.
 */
function swh_get_defaults() {
	static $defaults = null;
	if ( null === $defaults ) {
		$defaults = array(
			// General.
			'swh_ticket_priorities'          => 'Low, Medium, High',
			'swh_default_priority'           => 'Medium',
			'swh_ticket_statuses'            => 'Open, In Progress, Resolved, Closed',
			'swh_default_status'             => 'Open',
			'swh_resolved_status'            => 'Resolved',
			'swh_closed_status'              => 'Closed',
			'swh_reopened_status'            => 'Open',
			'swh_autoclose_days'             => 3,
			'swh_max_upload_size'            => 5,
			'swh_max_upload_count'           => 5,
			// Assignment & Routing.
			'swh_default_assignee'           => '',
			'swh_fallback_email'             => '',
			'swh_ticket_page_id'             => 0,
			'swh_token_expiration_days'      => 90,
			'swh_restrict_to_assigned'       => 'no',
			'swh_use_violet_theme'           => false,
			// Email Format.
			'swh_email_format'               => 'html',
			'swh_email_logo_url'             => '',
			// Anti-Spam.
			'swh_spam_method'                => 'honeypot',
			'swh_recaptcha_site_key'         => '',
			'swh_recaptcha_secret_key'       => '',
			'swh_recaptcha_type'             => 'v2',
			'swh_recaptcha_project_id'       => '',
			'swh_recaptcha_api_key'          => '',
			'swh_recaptcha_threshold'        => '0.5',
			'swh_turnstile_site_key'         => '',
			'swh_turnstile_secret_key'       => '',
			// Data Retention & Tools.
			'swh_retention_attachments_days' => 0,
			'swh_retention_tickets_days'     => 0,
			'swh_delete_on_uninstall'        => 'no',
			// Email Templates.
			'swh_em_user_new_sub'            => 'Ticket Received: [{ticket_id}] {title}',
			'swh_em_user_new_body'           => "Hi {name},\n\nWe have received your ticket (ID: {ticket_id}).\n\nYou can view your ticket status and reply to our technicians here:\n{ticket_url}",
			'swh_em_user_reply_sub'          => 'New Reply to Ticket [{ticket_id}] {title}',
			'swh_em_user_reply_body'         => "Hi {name},\n\nA technician has replied to your ticket.\n\n{if message}Reply:\n{message}\n\n{endif message}View conversation and reply here:\n{ticket_url}",
			'swh_em_user_status_sub'         => 'Status Updated: [{ticket_id}] {title}',
			'swh_em_user_status_body'        => "Hi {name},\n\nThe status of your ticket has been updated to: {status}\n\nView or reply to your ticket here:\n{ticket_url}",
			'swh_em_user_reply_status_sub'   => 'Ticket Updated: [{ticket_id}] {title}',
			'swh_em_user_reply_status_body'  => "Hi {name},\n\nA technician has replied to your ticket and the status is now: {status}.\n\n{if message}Reply:\n{message}\n\n{endif message}View conversation and reply here:\n{ticket_url}",
			'swh_em_user_resolved_sub'       => 'Ticket Resolved: [{ticket_id}] {title}',
			'swh_em_user_resolved_body'      => "Hi {name},\n\nYour ticket has been marked as resolved by a technician.\n\n{if message}Technician Note:\n{message}\n\n{endif message}{if autoclose_days}Please note: If we do not hear back from you, this ticket will be automatically closed in {autoclose_days} days.\n\n{endif autoclose_days}View or reply to your ticket here:\n{ticket_url}",
			'swh_em_user_reopen_sub'         => 'Ticket Re-Opened: [{ticket_id}] {title}',
			'swh_em_user_reopen_body'        => "Hi {name},\n\nYour ticket has been re-opened.\n\nView or reply to your ticket here:\n{ticket_url}",
			'swh_em_user_autoclose_sub'      => 'Ticket Auto-Closed: [{ticket_id}] {title}',
			'swh_em_user_autoclose_body'     => "Hi {name},\n\nSince we haven't heard from you recently, we have automatically closed your ticket.\n\nIf the problem still exists, you can re-open it by clicking the link below:\n{ticket_url}",
			'swh_em_user_closed_sub'         => 'Ticket Closed: [{ticket_id}] {title}',
			'swh_em_user_closed_body'        => "Hi {name},\n\nYou have successfully closed your ticket.\n\nView your ticket here:\n{ticket_url}",
			'swh_em_admin_new_sub'           => 'New Ticket Submitted: [{ticket_id}] {title}',
			'swh_em_admin_new_body'          => "A new ticket was submitted by {name}.\n\nPriority: {priority}\nTitle: {title}\n\nDescription:\n{message}\n\nView/Edit Ticket in Admin:\n{admin_url}",
			'swh_em_admin_reply_sub'         => 'Client Reply on Ticket [{ticket_id}] {title}',
			'swh_em_admin_reply_body'        => "{name} has replied to their ticket.\n\nReply:\n{message}\n\nView/Edit Ticket in Admin:\n{admin_url}",
			'swh_em_admin_reopen_sub'        => 'Ticket Re-Opened: [{ticket_id}] {title}',
			'swh_em_admin_reopen_body'       => "{name} has re-opened their ticket.\n\n{if message}Reason:\n{message}\n\n{endif message}View/Edit Ticket in Admin:\n{admin_url}",
			'swh_em_admin_closed_sub'        => 'Ticket Closed by Client: [{ticket_id}] {title}',
			'swh_em_admin_closed_body'       => "{name} has marked their ticket as closed.\n\nView/Edit Ticket in Admin:\n{admin_url}",
			'swh_em_assigned_sub'            => '[{ticket_id}] {title} Has Been Assigned to You',
			'swh_em_assigned_body'           => "Hi,\n\nTicket #{ticket_id} — {title} — has been assigned to you.\n\nPriority: {priority}\n\nView/Edit Ticket:\n{admin_url}",
			'swh_msg_success_new'            => 'Your ticket has been submitted successfully! Check your email for a secure link to track your ticket.',
			'swh_msg_success_reply'          => 'Your reply has been added.',
			'swh_msg_success_reopen'         => 'Your ticket has been successfully re-opened. Our team has been notified.',
			'swh_msg_success_closed'         => 'Your ticket has been successfully closed.',
			'swh_msg_err_spam'               => 'Anti-spam verification failed. Please try again.',
			'swh_msg_err_missing'            => 'Please fill in all required fields.',
			'swh_msg_err_invalid'            => 'Invalid or expired ticket link.',
			'swh_msg_err_expired'            => 'This ticket link has expired. Please use the lookup form below to receive a fresh link.',
			'swh_msg_success_lookup'         => 'If we have tickets on file for that email address, links have been sent.',
			// Lookup email template.
			'swh_em_user_lookup_sub'         => 'Your Open Tickets',
			'swh_em_user_lookup_body'        => "Hi,\n\nHere are links to your open helpdesk tickets:\n\n{ticket_links}\n\nIf you did not request this, you can safely ignore this email.",
			// Canned responses (structured array; registered here so factory reset + uninstall clean it up).
			'swh_canned_responses'           => array(),
			// Ticket templates (structured array; pre-configured submission types with pre-filled descriptions).
			'swh_ticket_templates'           => array(),
			// CC / Watchers.
			// (stored as _ticket_cc_emails post meta; no default option needed)
			// SLA.
			'swh_sla_warn_hours'             => '4',
			'swh_sla_breach_hours'           => '8',
			'swh_sla_notify_email'           => '',
			// Auto-assignment rules (JSON array of {category_term_id, assignee_user_id}).
			'swh_assignment_rules'           => array(),
			// Inbound email webhook.
			'swh_inbound_secret'             => '',
			// Email template: SLA breach digest.
			'swh_em_admin_sla_breach_sub'    => 'SLA Breach Alert: {sla_count} overdue ticket(s)',
			'swh_em_admin_sla_breach_body'   => "The following tickets have breached their SLA:\n\n{sla_list}",
			// Email templates: ticket merge notification.
			'swh_em_user_merged_sub'         => 'Your ticket has been merged: [{ticket_id}] {title}',
			'swh_em_user_merged_body'        => "Hi {name},\n\nYour ticket ({ticket_id}) has been merged into ticket {target_ticket_id}.\n\nYou can continue viewing your conversation here:\n{target_ticket_url}",
			// Frontend portal appearance.
			'swh_portal_theme'               => 'auto',
			// Admin theme (v4.0.0): light (default — Violet dark is incomplete),
			// dark (opt-in), auto (follow WP admin color scheme).
			'swh_admin_theme'                => 'light',
		);
	}
	return $defaults;
}

/**
 * Read a SWH setting from grouped storage.
 *
 * Reads `swh_settings_<group>` (an array option introduced in v4.0.0 #356)
 * and returns the value for $key, or $default if the group or key is absent.
 *
 * @since 3.7.0
 * @since 4.0.0 Body rewritten to read from `swh_settings_<group>` arrays.
 *              Signature is unchanged — callers are unaffected.
 * @param string $group   One of: 'general', 'email', 'portal', 'notifications',
 *                        'tools', 'routing', 'integrations'.
 * @param string $key     Setting key within the group, WITHOUT the 'swh_' prefix
 *                        (e.g. 'assignment_rules' → stored as key in swh_settings_routing).
 * @param mixed  $default Returned when the group or key is absent.
 * @return mixed
 */
function swh_get_option( string $group, string $key, $default = null ) { // phpcs:ignore Universal.NamingConventions.NoReservedKeywordParameterNames.defaultFound -- Signature locked for v4.0 #356; $default name preserved to match WP core `get_option()`.
	$bag = get_option( 'swh_settings_' . $group, array() );
	return is_array( $bag ) && array_key_exists( $key, $bag )
		? $bag[ $key ]
		: $default;
}

/**
 * Write a SWH setting to grouped storage.
 *
 * Reads the `swh_settings_<group>` array, updates $key, and writes it back.
 * Do NOT add caching here — WordPress's options API already caches per-request.
 *
 * @since 4.0.0
 * @param string $group One of: 'general', 'email', 'portal', 'notifications',
 *                      'tools', 'routing', 'integrations'.
 * @param string $key   Setting key within the group.
 * @param mixed  $value New value.
 * @return bool True on success, false on failure (mirrors update_option()).
 */
function swh_set_option( string $group, string $key, $value ): bool {
	$bag = get_option( 'swh_settings_' . $group, array() );
	if ( ! is_array( $bag ) ) {
		$bag = array();
	}
	$bag[ $key ] = $value;
	$result      = (bool) update_option( 'swh_settings_' . $group, $bag );

	// Back-compat: mirror the write to the legacy flat key for any key that
	// has an entry in the migration MAP. Keeps `get_option('swh_xxx')` and
	// `swh_get_string_option('swh_xxx')` etc. returning current values, even
	// though grouped storage is the source of truth.
	$flat_key = 'swh_' . $key;
	if ( class_exists( '\\SWH\\Settings\\Migration' )
		&& null !== \SWH\Settings\Migration::group_for( $flat_key ) ) {
		update_option( $flat_key, $value );
	}

	return $result;
}

/**
 * Filter a @wordpress/scripts asset-manifest dependency list to only handles
 * that exist in the current WordPress version.
 *
 * `@wordpress/scripts` may emit dependencies that don't exist on older WP
 * floors (e.g. `react-jsx-runtime` was introduced in WP 6.6). When wp_enqueue_script
 * is called with any unregistered dep, WP silently skips the enqueue. This helper
 * strips unknown handles so the script still loads on older WP versions.
 *
 * @since 4.0.0
 * @param array<mixed> $deps Raw dependency list from the asset manifest.
 * @return array<int, string> Filtered to only registered handles.
 */
function swh_filter_known_script_deps( array $deps ): array {
	$out = array();
	foreach ( $deps as $handle ) {
		if ( ! is_string( $handle ) || '' === $handle ) {
			continue;
		}
		if ( function_exists( 'wp_script_is' ) && wp_script_is( $handle, 'registered' ) ) {
			$out[] = $handle;
		}
	}
	return $out;
}

/**
 * Polyfill `window.ReactJSXRuntime` on WP < 6.6 by registering a fake
 * `react-jsx-runtime` script handle that depends on `wp-element` and
 * attaches the polyfill as an inline script.
 *
 * @wordpress/scripts compiles JSX to react-jsx-runtime imports that webpack
 * externalizes to `window.ReactJSXRuntime`. WP 6.6 ships a native handle;
 * earlier WP versions do not. Registering our own under the same handle
 * makes wp_enqueue_script work consistently across WP versions: the
 * dependency resolves, the inline polyfill runs after wp-element loads,
 * and the bundle finds window.ReactJSXRuntime when it executes.
 *
 * @since 4.0.0
 */
function swh_jsx_runtime_polyfill_register(): void {
	if ( ! function_exists( 'wp_register_script' ) ) {
		return;
	}
	if ( wp_script_is( 'react-jsx-runtime', 'registered' ) ) {
		return; // WP 6.6+ — native runtime present.
	}
	// Empty src — WP treats this as a virtual handle that just holds inline
	// scripts and propagates the wp-element dep.
	wp_register_script( 'react-jsx-runtime', '', array( 'wp-element' ), SWH_VERSION, true );
	$polyfill = <<<'JS'
( function () {
    if ( window.ReactJSXRuntime || ! ( window.wp && window.wp.element ) ) return;
    var createElement = window.wp.element.createElement;
    var Fragment = window.wp.element.Fragment;
    function jsx( type, props, key ) {
        var rest = {};
        for ( var k in props ) if ( k !== 'children' ) rest[ k ] = props[ k ];
        if ( typeof key !== 'undefined' ) rest.key = key;
        var children = props.children;
        if ( children === undefined || children === null ) return createElement( type, rest );
        if ( Array.isArray( children ) ) return createElement.apply( null, [ type, rest ].concat( children ) );
        return createElement( type, rest, children );
    }
    window.ReactJSXRuntime = { jsx: jsx, jsxs: jsx, jsxDEV: jsx, Fragment: Fragment };
} )();
JS;
	wp_add_inline_script( 'react-jsx-runtime', $polyfill );
}
add_action( 'init', 'swh_jsx_runtime_polyfill_register', 1 );
add_action( 'admin_init', 'swh_jsx_runtime_polyfill_register', 1 );

/**
 * Updates a ticket's status meta and fires the appropriate lifecycle actions.
 *
 * Wraps `update_post_meta( $ticket_id, '_ticket_status', $new_status )` and
 * dispatches the v3.7.0 status-transition actions:
 *
 * - `swh_ticket_status_changed` — fires on any transition.
 * - `swh_ticket_closed`         — fires on a non-closed → closed transition.
 * - `swh_ticket_reopened`       — fires on a closed → non-closed transition.
 *
 * Does nothing when `$new_status` matches the existing value. Initial-create
 * sites (no prior `_ticket_status` meta) should call `update_post_meta()`
 * directly so the `swh_ticket_created` action remains the single source of
 * truth for ticket creation.
 *
 * @since 3.7.0
 * @param int    $ticket_id  Ticket post ID.
 * @param string $new_status New status label.
 * @return void
 */
function swh_set_ticket_status( int $ticket_id, string $new_status ): void {
	$old_status = swh_get_string_meta( $ticket_id, '_ticket_status' );
	if ( $old_status === $new_status ) {
		return;
	}
	update_post_meta( $ticket_id, '_ticket_status', $new_status );
	update_post_meta( $ticket_id, '_swh_last_activity_at', time() );
	\SWH\Concurrency\TicketVersion::bump( $ticket_id );

	// Skip the change action when no prior status existed (initial create).
	if ( '' === $old_status ) {
		return;
	}

	/**
	 * Fires when a ticket's status changes.
	 *
	 * @since 3.7.0
	 * @param int    $ticket_id  Ticket post ID.
	 * @param string $old_status Previous status label.
	 * @param string $new_status New status label.
	 */
	do_action( 'swh_ticket_status_changed', $ticket_id, $old_status, $new_status );

	$defs            = swh_get_defaults();
	$closed_default  = is_string( $defs['swh_closed_status'] ) ? $defs['swh_closed_status'] : 'Closed';
	$closed_status   = swh_get_option( 'general', 'closed_status', $closed_default );
	$closed_statuses = is_array( $closed_status ) ? $closed_status : array( is_scalar( $closed_status ) ? (string) $closed_status : 'Closed' );

	$was_closed = in_array( $old_status, $closed_statuses, true );
	$is_closed  = in_array( $new_status, $closed_statuses, true );

	if ( ! $was_closed && $is_closed ) {
		/**
		 * Fires when a ticket transitions from a non-closed status to a closed status.
		 *
		 * @since 3.7.0
		 * @param int    $ticket_id       Ticket post ID.
		 * @param string $previous_status Status the ticket transitioned from.
		 */
		do_action( 'swh_ticket_closed', $ticket_id, $old_status );
	} elseif ( $was_closed && ! $is_closed ) {
		/**
		 * Fires when a ticket transitions from a closed status to a non-closed status.
		 *
		 * @since 3.7.0
		 * @param int    $ticket_id       Ticket post ID.
		 * @param string $previous_status Status the ticket transitioned from.
		 */
		do_action( 'swh_ticket_reopened', $ticket_id, $old_status );
	}
}

/**
 * Fires `swh_ticket_replied` after a helpdesk reply comment is inserted.
 *
 * Centralises the staff-detection logic: an author is treated as a staff
 * reply when the comment user has the `edit_post` capability on the ticket.
 * System-generated comments (cron auto-close, retention notes, merge
 * breadcrumbs, portal client replies) report `false`.
 *
 * @since 3.7.0
 * @param int            $ticket_id  Ticket post ID.
 * @param int|false|null $comment_id Comment ID returned by `wp_insert_comment()`.
 *                                   A falsy value (0, false, or null) short-circuits the action.
 * @param int            $author_id  User ID of the comment author. Use 0 for
 *                                   system-generated comments or guests.
 * @return void
 */
function swh_fire_ticket_replied( int $ticket_id, $comment_id, int $author_id = 0 ): void {
	if ( ! $comment_id ) {
		return;
	}
	$is_staff_reply = false;
	if ( $author_id > 0 ) {
		$is_staff_reply = (bool) user_can( $author_id, 'edit_post', $ticket_id );
	}
	/**
	 * Fires after a reply comment is inserted on a ticket.
	 *
	 * @since 3.7.0
	 * @param int  $ticket_id      Ticket post ID.
	 * @param int  $comment_id     The inserted comment ID.
	 * @param bool $is_staff_reply True when the comment author has the
	 *                             `edit_post` capability on the ticket
	 *                             (admins, technicians); false for client
	 *                             replies and system-generated comments.
	 */
	do_action( 'swh_ticket_replied', $ticket_id, (int) $comment_id, $is_staff_reply );
}

/**
 * Returns all plugin option keys managed by defaults (excludes swh_db_version).
 *
 * @return string[] List of option key names.
 */
function swh_get_all_option_keys() {
	// swh_db_version is managed separately and excluded from bulk operations.
	return array_keys( swh_get_defaults() );
}

/**
 * Returns the configured list of ticket statuses.
 *
 * @return string[] Trimmed status label strings.
 */
function swh_get_statuses() {
	$defs             = swh_get_defaults();
	$default_statuses = is_string( $defs['swh_ticket_statuses'] ) ? $defs['swh_ticket_statuses'] : '';
	$statuses         = array_map( 'trim', explode( ',', swh_get_string_option( 'swh_ticket_statuses', $default_statuses ) ) );
	/**
	 * Filters the list of available ticket statuses.
	 *
	 * @deprecated 4.0 Retained for back-compat through SWH 4.2.
	 * @since 2.1.0
	 * @param string[] $statuses Array of status label strings.
	 */
	return swh_apply_deprecated_filter(
		'swh_ticket_statuses',
		array( $statuses ),
		'4.0',
		'',
		'Filter is retained for back-compat through SWH 4.2; no direct replacement yet.'
	);
}

/**
 * Returns the configured list of ticket priorities.
 *
 * @return string[] Trimmed priority label strings.
 */
function swh_get_priorities() {
	$defs               = swh_get_defaults();
	$default_priorities = is_string( $defs['swh_ticket_priorities'] ) ? $defs['swh_ticket_priorities'] : '';
	$priorities         = array_map( 'trim', explode( ',', swh_get_string_option( 'swh_ticket_priorities', $default_priorities ) ) );
	/**
	 * Filters the list of available ticket priorities.
	 *
	 * @deprecated 4.0 Retained for back-compat through SWH 4.2.
	 * @since 2.1.0
	 * @param string[] $priorities Array of priority label strings.
	 */
	return swh_apply_deprecated_filter(
		'swh_ticket_priorities',
		array( $priorities ),
		'4.0',
		'',
		'Filter is retained for back-compat through SWH 4.2; no direct replacement yet.'
	);
}

/**
 * Builds a secure client portal URL for a ticket using its token.
 *
 * Uses the configured helpdesk page ID if set; falls back to the stored _ticket_url meta.
 * Returns false if the ticket has no token or no base URL is available.
 *
 * @param int $ticket_id The ticket post ID.
 * @return string|false The full portal URL with token, or false on failure.
 */
function swh_get_secure_ticket_link( $ticket_id ) {
	$token = get_post_meta( $ticket_id, '_ticket_token', true );
	if ( ! $token ) {
		return false;
	}
	$page_id  = swh_get_int_option( 'swh_ticket_page_id', 0 );
	$base_url = $page_id ? get_permalink( $page_id ) : swh_get_string_meta( $ticket_id, '_ticket_url' );
	if ( ! $base_url ) {
		return false;
	}
	return add_query_arg(
		array(
			'swh_ticket' => $ticket_id,
			'token'      => $token,
		),
		$base_url
	);
}

/**
 * Checks whether a ticket's portal token has exceeded its configured TTL.
 *
 * Tickets created before v1.9.0 (without _ticket_token_created) are grandfathered
 * and never considered expired. A TTL of 0 also disables expiration.
 *
 * @param int $ticket_id The ticket post ID.
 * @return bool True if the token is expired, false otherwise.
 */
function swh_is_token_expired( $ticket_id ) {
	$days = swh_get_int_option( 'swh_token_expiration_days', 90 );
	if ( 0 === $days ) {
		return false;
	}
	$created = swh_get_int_meta( $ticket_id, '_ticket_token_created' );
	if ( ! $created ) {
		return false;
	}
	return ( time() - $created ) > ( $days * DAY_IN_SECONDS );
}

/**
 * Returns the client IP address, respecting Cloudflare and reverse proxy headers.
 *
 * Checks CF-Connecting-IP, X-Forwarded-For, then REMOTE_ADDR in order.
 * Never accesses REMOTE_ADDR directly.
 *
 * @return string The client IP address, or empty string if unavailable.
 */
function swh_get_client_ip() {
	if ( ! empty( $_SERVER['HTTP_CF_CONNECTING_IP'] ) && is_string( $_SERVER['HTTP_CF_CONNECTING_IP'] ) ) {
		return sanitize_text_field( wp_unslash( $_SERVER['HTTP_CF_CONNECTING_IP'] ) );
	}
	if ( ! empty( $_SERVER['HTTP_X_FORWARDED_FOR'] ) && is_string( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) {
		$ips = explode( ',', sanitize_text_field( wp_unslash( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) );
		return trim( $ips[0] );
	}
	return isset( $_SERVER['REMOTE_ADDR'] ) && is_string( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
}

/**
 * Runs the configured anti-spam check (honeypot, reCAPTCHA, or Turnstile).
 *
 * Returns true if spam is detected (i.e., the submission should be blocked).
 *
 * @param bool $check_captcha Whether to check CAPTCHA (skip on lookup forms that have no CAPTCHA).
 * @return bool True if the submission is spam, false if it is legitimate.
 */
function swh_check_antispam( $check_captcha = true ) {
	$method = swh_get_option( 'tools', 'spam_method', 'honeypot' );
	if ( 'honeypot' === $method && ! empty( $_POST['swh_website_url_hp'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
		return true;
	}
	if ( ! $check_captcha ) {
		return false;
	}
	if ( 'recaptcha' === $method ) {
		$recaptcha_type = swh_get_string_option( 'swh_recaptcha_type', 'v2' );
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- reCAPTCHA token has no nonce; validated server-side by Google's API.
		$token = isset( $_POST['g-recaptcha-response'] ) && is_string( $_POST['g-recaptcha-response'] ) ? sanitize_text_field( wp_unslash( $_POST['g-recaptcha-response'] ) ) : '';
		if ( 'enterprise' === $recaptcha_type ) {
			$project_id = swh_get_string_option( 'swh_recaptcha_project_id' );
			$api_key    = swh_get_string_option( 'swh_recaptcha_api_key' );
			$site_key   = swh_get_string_option( 'swh_recaptcha_site_key' );
			$threshold  = (float) swh_get_string_option( 'swh_recaptcha_threshold', '0.5' );
			if ( ! $project_id || ! $api_key ) {
				return true; // Fail closed: missing credentials → reject submission.
			}
			$body = wp_json_encode(
				array(
					'event' => array(
						'token'   => $token,
						'siteKey' => $site_key,
					),
				)
			);
			if ( false === $body ) {
				return true;
			}
			$resp = wp_remote_post(
				'https://recaptchaenterprise.googleapis.com/v1/projects/' . rawurlencode( $project_id ) . '/assessments?key=' . rawurlencode( $api_key ),
				array(
					'headers' => array( 'Content-Type' => 'application/json' ),
					'body'    => $body,
					'timeout' => 10,
				)
			);
			$json = json_decode( wp_remote_retrieve_body( $resp ) );
			if (
				! is_object( $json )
				|| empty( $json->tokenProperties->valid ) // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
				|| empty( $json->riskAnalysis->score ) // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
				|| (float) $json->riskAnalysis->score < $threshold // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
			) {
				return true;
			}
		} else {
			$resp = wp_remote_post(
				'https://www.google.com/recaptcha/api/siteverify',
				array(
					'body'    => array(
						'secret'   => swh_get_string_option( 'swh_recaptcha_secret_key' ),
						'response' => $token,
					),
					'timeout' => 10,
				)
			);
			$json = json_decode( wp_remote_retrieve_body( $resp ) );
			if ( ! is_object( $json ) || empty( $json->success ) ) {
				return true;
			}
		}
	} elseif ( 'turnstile' === $method ) {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Turnstile token has no nonce; validated server-side by Cloudflare's API.
		$turnstile_token = isset( $_POST['cf-turnstile-response'] ) && is_string( $_POST['cf-turnstile-response'] ) ? sanitize_text_field( wp_unslash( $_POST['cf-turnstile-response'] ) ) : '';
		$resp            = wp_remote_post(
			'https://challenges.cloudflare.com/turnstile/v0/siteverify',
			array(
				'body'    => array(
					'secret'   => swh_get_string_option( 'swh_turnstile_secret_key' ),
					'response' => $turnstile_token,
				),
				'timeout' => 10,
			)
		);
		$json            = json_decode( wp_remote_retrieve_body( $resp ) );
		if ( ! is_object( $json ) || empty( $json->success ) ) {
			return true;
		}
	}
	return false;
}

/**
 * Returns a post meta value cast to string.
 *
 * Wrapper around get_post_meta() that guarantees a string return type for
 * PHPStan L9 compatibility.
 *
 * @param int    $post_id Post ID.
 * @param string $key     Meta key.
 * @return string
 */
function swh_get_string_meta( int $post_id, string $key ): string {
	$val = get_post_meta( $post_id, $key, true );
	return is_scalar( $val ) ? (string) $val : '';
}

/**
 * Returns a post meta value cast to int.
 *
 * @param int    $post_id Post ID.
 * @param string $key     Meta key.
 * @return int
 */
function swh_get_int_meta( int $post_id, string $key ): int {
	$val = get_post_meta( $post_id, $key, true );
	return is_scalar( $val ) ? intval( $val ) : 0;
}

/**
 * Returns an option value cast to string.
 *
 * @param string $key      Option name.
 * @param string $fallback Default value if option not set.
 * @return string
 */
function swh_get_string_option( string $key, string $fallback = '' ): string {
	$val = get_option( $key, $fallback );
	return is_scalar( $val ) ? (string) $val : $fallback;
}

/**
 * Returns an option value cast to int.
 *
 * @param string $key      Option name.
 * @param int    $fallback Default value if option not set.
 * @return int
 */
function swh_get_int_option( string $key, int $fallback = 0 ): int {
	$val = get_option( $key, $fallback );
	return is_scalar( $val ) ? intval( $val ) : $fallback;
}

/**
 * Returns a comment meta value cast to string.
 *
 * @param int    $comment_id Comment ID.
 * @param string $key        Meta key.
 * @return string
 */
function swh_get_string_comment_meta( int $comment_id, string $key ): string {
	$val = get_comment_meta( $comment_id, $key, true );
	return is_scalar( $val ) ? (string) $val : '';
}

/**
 * Returns CC/watcher email addresses for a ticket.
 *
 * Reads `_ticket_cc_emails` post meta (comma-separated), sanitizes each address,
 * and returns only valid email addresses.
 *
 * @since 3.0.0
 * @param int $ticket_id The ticket post ID.
 * @return string[] Array of sanitized, valid email addresses.
 */
function swh_get_cc_emails( int $ticket_id ): array {
	$raw = swh_get_string_meta( $ticket_id, '_ticket_cc_emails' );
	if ( ! $raw ) {
		return array();
	}
	$emails = array_map( 'sanitize_email', array_map( 'trim', explode( ',', $raw ) ) );
	return array_values(
		array_filter(
			$emails,
			function ( string $addr ): bool {
				return (bool) is_email( $addr );
			}
		)
	);
}

/**
 * Applies auto-assignment rules to a ticket, setting `_ticket_assigned_to`.
 *
 * Checks each configured rule ({category_term_id, assignee_user_id}) against
 * the ticket's `helpdesk_category` taxonomy terms. First matching rule wins.
 * Falls back to `swh_default_assignee` option if no rule matches.
 *
 * @since 3.0.0
 * @param int $ticket_id The ticket post ID.
 * @return void
 */
function swh_apply_assignment_rules( int $ticket_id ): void {
	$rules_raw = swh_get_option( 'routing', 'assignment_rules', array() );
	$rules     = is_array( $rules_raw ) ? $rules_raw : array();
	$assigned  = 0;

	if ( ! empty( $rules ) ) {
		$term_ids = wp_get_post_terms( $ticket_id, 'helpdesk_category', array( 'fields' => 'ids' ) );
		if ( is_array( $term_ids ) && ! empty( $term_ids ) ) {
			foreach ( $rules as $rule ) {
				if ( ! is_array( $rule ) || empty( $rule['category_term_id'] ) || empty( $rule['assignee_user_id'] ) ) {
					continue;
				}
				$cat_term_id = is_scalar( $rule['category_term_id'] ) ? (int) $rule['category_term_id'] : 0;
				$assignee_id = is_scalar( $rule['assignee_user_id'] ) ? (int) $rule['assignee_user_id'] : 0;
				if ( in_array( $cat_term_id, $term_ids, true ) ) {
					$assigned = $assignee_id;
					break;
				}
			}
		}
	}

	if ( ! $assigned ) {
		$default  = swh_get_option( 'routing', 'default_assignee' );
		$assigned = is_scalar( $default ) ? (int) $default : 0;
	}

	if ( $assigned > 0 ) {
		$old_assigned = swh_get_int_meta( $ticket_id, '_ticket_assigned_to' );
		update_post_meta( $ticket_id, '_ticket_assigned_to', $assigned );
		if ( $old_assigned !== $assigned ) {
			/**
			 * Fires when a ticket's assignee changes.
			 *
			 * @since 3.7.0
			 * @param int $ticket_id   Ticket post ID.
			 * @param int $old_user_id Previous assignee user ID (0 if unassigned).
			 * @param int $new_user_id New assignee user ID (0 if unassigned).
			 */
			do_action( 'swh_ticket_assigned', $ticket_id, $old_assigned, $assigned );
		}
	}
}

/**
 * Merges source ticket into target ticket.
 *
 * Moves all helpdesk_reply comments from source to target, consolidates attachment
 * origname maps, adds system notes to both tickets, closes the source with an
 * internal note, and sends the client a notification linking to the target.
 *
 * @since 3.0.0
 * @param int $source_id Ticket to merge from (will be closed).
 * @param int $target_id Ticket to merge into (receives all conversation).
 * @return bool True on success, false if either post is invalid.
 */
function swh_merge_tickets( int $source_id, int $target_id ): bool {
	$source = get_post( $source_id );
	$target = get_post( $target_id );
	if ( ! $source || ! $target || 'helpdesk_ticket' !== $source->post_type || 'helpdesk_ticket' !== $target->post_type ) {
		return false;
	}

	// Move all helpdesk_reply comments from source to target.
	$comments = get_comments(
		array(
			'post_id' => $source_id,
			'type'    => 'helpdesk_reply',
			'status'  => 'approve',
			'number'  => 0,
			'order'   => 'ASC',
		)
	);
	$comments = is_array( $comments ) ? $comments : array();
	foreach ( $comments as $comment ) {
		if ( ! $comment instanceof WP_Comment ) {
			continue;
		}
		wp_update_comment(
			array(
				'comment_ID'      => $comment->comment_ID,
				'comment_post_ID' => $target_id,
			)
		);
	}

	// Merge root-level attachment URLs (files attached to the ticket, not to a reply comment).
	$source_attach = get_post_meta( $source_id, '_ticket_attachments', true );
	$target_attach = get_post_meta( $target_id, '_ticket_attachments', true );
	if ( is_array( $source_attach ) && ! empty( $source_attach ) ) {
		$merged_attach = is_array( $target_attach ) ? array_merge( $target_attach, $source_attach ) : $source_attach;
		update_post_meta( $target_id, '_ticket_attachments', $merged_attach );
	}

	// Merge attachment orignames (URL → original filename maps).
	$source_names = get_post_meta( $source_id, '_swh_attachment_orignames', true );
	$target_names = get_post_meta( $target_id, '_swh_attachment_orignames', true );
	if ( is_array( $source_names ) && ! empty( $source_names ) ) {
		$merged = is_array( $target_names ) ? array_merge( $target_names, $source_names ) : $source_names;
		update_post_meta( $target_id, '_swh_attachment_orignames', $merged );
	}

	// Add system notes.
	$source_uid        = swh_get_string_meta( $source_id, '_ticket_uid' );
	$target_uid        = swh_get_string_meta( $target_id, '_ticket_uid' );
	$target_comment_id = wp_insert_comment(
		array(
			'comment_post_ID'  => $target_id,
			'comment_type'     => 'helpdesk_reply',
			'comment_content'  => sprintf( 'Merged from ticket %s.', $source_uid ),
			'comment_approved' => 1,
			'comment_meta'     => array( '_is_internal_note' => '1' ),
		)
	);
	swh_fire_ticket_replied( $target_id, $target_comment_id, 0 );
	$source_comment_id = wp_insert_comment(
		array(
			'comment_post_ID'  => $source_id,
			'comment_type'     => 'helpdesk_reply',
			'comment_content'  => sprintf( 'Merged into ticket %s.', $target_uid ),
			'comment_approved' => 1,
			'comment_meta'     => array( '_is_internal_note' => '1' ),
		)
	);
	swh_fire_ticket_replied( $source_id, $source_comment_id, 0 );

	// Close the source ticket.
	$defs          = swh_get_defaults();
	$closed_status = swh_get_string_option( 'swh_closed_status', is_string( $defs['swh_closed_status'] ) ? $defs['swh_closed_status'] : 'Closed' );
	swh_set_ticket_status( $source_id, $closed_status );

	// Notify source ticket client.
	$client_email = swh_get_string_meta( $source_id, '_ticket_email' );
	$client_name  = swh_get_string_meta( $source_id, '_ticket_name' );
	$target_link  = swh_get_secure_ticket_link( $target_id );
	if ( $client_email && $target_link ) {
		$mail_data = array(
			'name'              => $client_name,
			'ticket_id'         => $source_uid,
			'target_ticket_id'  => $target_uid,
			'target_ticket_url' => $target_link,
		);
		swh_send_email( $client_email, 'swh_em_user_merged_sub', 'swh_em_user_merged_body', $mail_data );
	}

	return true;
}

/**
 * Formats a comment's date/time string using the WP site timezone and locale.
 *
 * Uses `comment_date_gmt` (UTC) as the source so the result is correct
 * regardless of any mismatch between the PHP server timezone and the WP
 * site timezone setting.
 *
 * @since 3.1.0
 * @param WP_Comment $comment The comment object.
 * @return string Formatted date string in the site locale and timezone.
 */
function swh_format_comment_date( WP_Comment $comment ): string {
	$gmt       = $comment->comment_date_gmt;
	$utc_ts    = $gmt ? strtotime( $gmt . ' UTC' ) : false;
	$utc_ts    = false !== $utc_ts ? $utc_ts : time();
	$date_fmt  = get_option( 'date_format' );
	$time_fmt  = get_option( 'time_format' );
	$format    = ( is_string( $date_fmt ) ? $date_fmt : 'F j, Y' ) . ' ' . ( is_string( $time_fmt ) ? $time_fmt : 'g:i a' );
	$localized = wp_date( $format, $utc_ts );
	return is_string( $localized ) ? $localized : gmdate( 'Y-m-d H:i', $utc_ts );
}

/**
 * Returns the count of tickets with unread client replies.
 *
 * A ticket is "unread" when `_swh_unread` post meta equals `1`, set whenever
 * a client posts a reply via the portal or inbound email webhook.
 * Result is cached in a 5-minute transient to avoid per-request WP_Query overhead.
 *
 * @since 3.1.0
 * @return int Number of tickets with unread client replies.
 */
function swh_get_unread_reply_count(): int {
	$cached = get_transient( 'swh_unread_count' );
	if ( false !== $cached ) {
		return is_scalar( $cached ) ? intval( $cached ) : 0;
	}
	$query = new WP_Query(
		array(
			'post_type'      => 'helpdesk_ticket',
			'post_status'    => 'publish',
			'posts_per_page' => -1,
			'fields'         => 'ids',
			// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
			'meta_query'     => array(
				array(
					'key'   => '_swh_unread',
					'value' => '1',
				),
			),
			'no_found_rows'  => true,
		)
	);
	$count = count( $query->posts );
	set_transient( 'swh_unread_count', $count, 5 * MINUTE_IN_SECONDS );
	return $count;
}

/**
 * Checks and sets a rate-limit lock keyed by action name and client IP.
 *
 * Returns true if the client is currently rate-limited. When not limited,
 * sets the lock and returns false. Portal actions use per-action keys
 * (portal_close_, portal_reopen_, portal_reply_) to prevent interference.
 *
 * @param string $action A unique action identifier (e.g. 'portal_reply_42').
 * @param int    $ttl    Lock duration in seconds. Default 30.
 * @return bool True if rate-limited, false if the action is allowed.
 */
function swh_is_rate_limited( $action, $ttl = 30 ) {
	/**
	 * Filters the rate-limit TTL (in seconds) for a given action.
	 *
	 * @deprecated 4.0 Retained for back-compat through SWH 4.2.
	 * @since 2.1.0
	 * @param int    $ttl    Lock duration in seconds.
	 * @param string $action The action identifier being rate-limited.
	 */
	$filtered_ttl = swh_apply_deprecated_filter(
		'swh_rate_limit_ttl',
		array( $ttl, $action ),
		'4.0',
		'',
		'Filter is retained for back-compat through SWH 4.2; no direct replacement yet.'
	);
	$ttl          = is_scalar( $filtered_ttl ) ? intval( $filtered_ttl ) : $ttl;
	$key          = 'swh_rl_' . md5( $action . '_' . swh_get_client_ip() );
	$val          = get_option( $key );
	if ( false !== $val && is_scalar( $val ) && intval( $val ) > time() ) {
		return true;
	}
	update_option( $key, time() + $ttl, false );
	return false;
}

if ( ! function_exists( 'swh_render_empty_state' ) ) {
	/**
	 * Renders the shared empty-state component with a configurable heading level.
	 *
	 * Use to keep heading hierarchy correct: pass 'h2' when the empty state
	 * stands in for a section that would otherwise have an h2; pass a deeper
	 * level when it sits inside a section that already has its own h2.
	 *
	 * @since 3.6.0
	 * @param string $title         Translated title text (will be escaped).
	 * @param string $desc          Translated description text (will be escaped).
	 * @param string $icon_svg_path SVG <path> markup contents (no <svg> wrapper).
	 * @param string $heading_level One of 'h1','h2','h3','h4','h5','h6'. Default 'h2'.
	 * @return void
	 */
	function swh_render_empty_state( $title, $desc, $icon_svg_path, $heading_level = 'h2' ) {
		$allowed = array( 'h1', 'h2', 'h3', 'h4', 'h5', 'h6' );
		$tag     = in_array( $heading_level, $allowed, true ) ? $heading_level : 'h2';
		echo '<div class="swh-empty-state">';
		echo '<svg class="swh-empty-state-icon" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">' . wp_kses(
			$icon_svg_path,
			array(
				'path' => array(
					'd'         => array(),
					'fill-rule' => array(),
					'clip-rule' => array(),
				),
			)
		) . '</svg>';
		echo '<' . esc_attr( $tag ) . ' class="swh-empty-state-title">' . esc_html( $title ) . '</' . esc_attr( $tag ) . '>';
		echo '<p class="swh-empty-state-desc">' . esc_html( $desc ) . '</p>';
		echo '</div>';
	}
}

if ( ! function_exists( 'swh_admin_ticket_url' ) ) {
	/**
	 * Build the admin URL that opens a ticket. v4.0.0+ deep-links into the
	 * React inbox drawer; pre-v4 callers got the legacy post-editor URL.
	 *
	 * @since 4.0.0
	 * @param int $ticket_id Ticket post ID.
	 * @return string
	 */
	function swh_admin_ticket_url( $ticket_id ) {
		return admin_url( 'edit.php?post_type=helpdesk_ticket#ticket=' . (int) $ticket_id );
	}
}

if ( ! function_exists( 'swh_admin_color_is_dark' ) ) {
	/**
	 * Returns true when the current user's WP admin colour scheme is one of the
	 * dark variants we mirror for SWH admin pages (midnight, modern, ectoplasm).
	 *
	 * @since 3.6.0
	 * @return bool
	 */
	function swh_admin_color_is_dark() {
		// v4.0.0: admin_theme setting overrides the auto-detect.
		// Default 'light' — the dark variant of the Violet theme is incomplete
		// and produces visual issues on the inbox; opt-in only until v4.1.
		$setting = swh_get_string_option( 'swh_admin_theme', 'light' );
		if ( 'light' === $setting ) {
			return false;
		}
		if ( 'dark' === $setting ) {
			return true;
		}
		// 'auto' — follow the WP admin colour scheme (midnight/modern/ectoplasm).
		$dark_schemes = array( 'midnight', 'modern', 'ectoplasm' );
		$user_id      = get_current_user_id();
		if ( ! $user_id ) {
			return false;
		}
		$scheme = get_user_option( 'admin_color', $user_id );
		if ( ! is_string( $scheme ) || '' === $scheme ) {
			$scheme = 'fresh';
		}
		return in_array( $scheme, $dark_schemes, true );
	}
}

if ( ! function_exists( 'swh_enqueue_toast_script' ) ) {
	/**
	 * Enqueue the built `swh-toast` script (built via @wordpress/scripts to
	 * `assets/dist/toast.js`) which exposes `window.swhToast()`.
	 *
	 * Reads the generated `toast.asset.php` for dependencies + hashed version
	 * so cache-busting and dep-management are automatic.
	 *
	 * @since 3.7.0
	 * @return void
	 */
	function swh_enqueue_toast_script() {
		// Build the asset manifest path through a variable so static analysers
		// (PHPStan) do not attempt to resolve the generated file at lint time.
		$asset_rel  = 'assets/dist/toast.asset.php';
		$asset_file = SWH_PLUGIN_DIR . $asset_rel;
		$deps       = array();
		$version    = SWH_VERSION;
		if ( file_exists( $asset_file ) ) {
			// @phpstan-ignore-next-line include.fileNotFound
			$asset = include $asset_file; // phpcs:ignore WordPressVIPMinimum.Files.IncludingFile.UsingVariable
			if ( is_array( $asset ) ) {
				if ( isset( $asset['dependencies'] ) && is_array( $asset['dependencies'] ) ) {
					// Keep only string dependency handles to satisfy wp_enqueue_script's signature.
					$deps = array_values( array_filter( $asset['dependencies'], 'is_string' ) );
				}
				if ( isset( $asset['version'] ) && is_string( $asset['version'] ) ) {
					$version = $asset['version'];
				}
			}
		}
		wp_enqueue_script(
			'swh-toast',
			SWH_PLUGIN_URL . 'assets/dist/toast.js',
			$deps,
			$version,
			true
		);
	}
}
