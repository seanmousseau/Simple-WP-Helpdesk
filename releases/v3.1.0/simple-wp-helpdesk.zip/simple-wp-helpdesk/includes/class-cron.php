<?php
/**
 * Background cron tasks: auto-close, attachment retention, ticket retention, and SLA breach alerts.
 *
 * All tasks are micro-batched (1–2 tickets per run) to prevent cURL error 28 timeouts.
 *
 * @package Simple_WP_Helpdesk
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ==============================================================================
// BACKGROUND CRON TASKS (Micro-Batched to prevent cURL error 28)
// ==============================================================================

/**
 * Processes the auto-close cron event: closes resolved tickets past the inactivity threshold.
 *
 * @see swh_process_autoclose()
 */
add_action( 'swh_autoclose_event', 'swh_process_autoclose' );
/**
 * Auto-closes tickets that have been in Resolved status longer than the configured threshold.
 *
 * Also purges expired rate-limit entries on each run. Processes 2 tickets per invocation.
 * Uses a transient lock to prevent concurrent runs.
 *
 * @return void
 */
function swh_process_autoclose() {
	// Clean up expired rate-limit entries.
	global $wpdb;
	$wpdb->query(
		$wpdb->prepare(
			"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s AND option_value < %d",
			'swh\_rl\_%',
			time()
		)
	);

	$defs = swh_get_defaults();
	$days = swh_get_int_option( 'swh_autoclose_days', 3 );
	/**
	 * Filters the number of days before a resolved ticket is automatically closed.
	 *
	 * @since 2.1.0
	 * @param int $days Number of inactivity days. 0 disables auto-close.
	 */
	$filtered_days = apply_filters( 'swh_autoclose_threshold', $days );
	$days          = is_scalar( $filtered_days ) ? intval( $filtered_days ) : $days;
	if ( $days <= 0 ) {
		return;
	}
	$lock_key = 'swh_lock_autoclose';
	if ( get_transient( $lock_key ) ) {
		return;
	}
	set_transient( $lock_key, 1, 5 * MINUTE_IN_SECONDS );
	$resolved_status = get_option( 'swh_resolved_status', $defs['swh_resolved_status'] );
	$closed_status   = get_option( 'swh_closed_status', $defs['swh_closed_status'] );
	$threshold       = time() - ( $days * DAY_IN_SECONDS );

    // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
	$tickets = get_posts(
		array(
			'post_type'      => 'helpdesk_ticket',
			'posts_per_page' => 2,
			'meta_query'     => array(
				'relation' => 'AND',
				array(
					'key'   => '_ticket_status',
					'value' => $resolved_status,
				),
				array(
					'key'     => '_resolved_timestamp',
					'value'   => $threshold,
					'compare' => '<=',
					'type'    => 'NUMERIC',
				),
			),
		)
	);
	if ( ! empty( $tickets ) ) {
		update_meta_cache( 'post', wp_list_pluck( $tickets, 'ID' ) );
	}
	foreach ( $tickets as $ticket ) {
		update_post_meta( $ticket->ID, '_ticket_status', $closed_status );
		$comment_id = wp_insert_comment(
			array(
				'comment_post_ID'  => $ticket->ID,
				'comment_author'   => __( 'System Auto-Close', 'simple-wp-helpdesk' ),
				/* translators: %d: number of days of inactivity */
				'comment_content'  => sprintf( __( 'Ticket automatically closed due to inactivity (%d days).', 'simple-wp-helpdesk' ), $days ),
				'comment_approved' => 1,
				'comment_type'     => 'helpdesk_reply',
			)
		);
		if ( $comment_id ) {
			update_comment_meta( $comment_id, '_is_internal_note', '1' );
		}

		$ticket_email = swh_get_string_meta( $ticket->ID, '_ticket_email' );
		$ticket_name  = swh_get_string_meta( $ticket->ID, '_ticket_name' );
		$data         = array(
			'name'           => $ticket_name ? $ticket_name : 'Client',
			'email'          => $ticket_email,
			'ticket_id'      => swh_get_string_meta( $ticket->ID, '_ticket_uid' ),
			'title'          => $ticket->post_title,
			'status'         => $closed_status,
			'priority'       => swh_get_string_meta( $ticket->ID, '_ticket_priority' ),
			'ticket_url'     => swh_get_secure_ticket_link( $ticket->ID ),
			'admin_url'      => admin_url( 'post.php?post=' . $ticket->ID . '&action=edit' ),
			'autoclose_days' => $days,
			'message'        => '',
		);
		if ( $ticket_email && $data['ticket_url'] ) {
			swh_send_email( $ticket_email, 'swh_em_user_autoclose_sub', 'swh_em_user_autoclose_body', $data );
		}
	}
	delete_transient( $lock_key );
}

/**
 * Processes the attachment retention cron event: deletes files older than the threshold.
 *
 * @see swh_process_retention_attachments()
 */
add_action( 'swh_retention_attachments_event', 'swh_process_retention_attachments' );
/**
 * Purges attachments from tickets and replies older than the retention threshold.
 *
 * Processes 1 ticket and 1 reply batch per invocation. Uses a transient lock.
 * Appends a note to comment content when reply attachments are purged.
 *
 * @return void
 */
function swh_process_retention_attachments() {
	$days = swh_get_int_option( 'swh_retention_attachments_days', 0 );
	if ( $days <= 0 ) {
		return;
	}
	$lock_key = 'swh_lock_retention_att';
	if ( get_transient( $lock_key ) ) {
		return;
	}
	set_transient( $lock_key, 1, 5 * MINUTE_IN_SECONDS );
	$threshold_date = gmdate( 'Y-m-d H:i:s', time() - ( $days * DAY_IN_SECONDS ) );

    // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
	$tickets = get_posts(
		array(
			'post_type'      => 'helpdesk_ticket',
			'posts_per_page' => 1,
			'date_query'     => array(
				array(
					'column' => 'post_modified',
					'before' => $threshold_date,
				),
			),
			'meta_query'     => array(
				array(
					'key'     => '_ticket_attachments',
					'compare' => 'EXISTS',
				),
			),
		)
	);
	if ( ! empty( $tickets ) ) {
		update_meta_cache( 'post', wp_list_pluck( $tickets, 'ID' ) );
	}
	foreach ( $tickets as $ticket ) {
		$atts = get_post_meta( $ticket->ID, '_ticket_attachments', true );
		if ( ! empty( $atts ) ) {
			if ( ! is_array( $atts ) ) {
				$atts = array( $atts );
			}
			foreach ( $atts as $url ) {
				if ( is_string( $url ) ) {
					swh_delete_file_by_url( $url );
				}
			}
			delete_post_meta( $ticket->ID, '_ticket_attachments' );
			$comment_id = wp_insert_comment(
				array(
					'comment_post_ID'  => $ticket->ID,
					'comment_author'   => __( 'System Maintenance', 'simple-wp-helpdesk' ),
					/* translators: %d: number of days for retention */
					'comment_content'  => sprintf( __( 'Original ticket attachments automatically purged (older than %d days).', 'simple-wp-helpdesk' ), $days ),
					'comment_approved' => 1,
					'comment_type'     => 'helpdesk_reply',
				)
			);
			if ( $comment_id ) {
				update_comment_meta( $comment_id, '_is_internal_note', '1' );
			}
		}
		// Handle legacy single-URL attachment format.
		$legacy_url = swh_get_string_meta( $ticket->ID, '_ticket_attachment_url' );
		if ( $legacy_url ) {
			swh_delete_file_by_url( $legacy_url );
			delete_post_meta( $ticket->ID, '_ticket_attachment_url' );
		}
		$legacy_id = swh_get_int_meta( $ticket->ID, '_ticket_attachment_id' );
		if ( $legacy_id ) {
			wp_delete_attachment( $legacy_id, true );
			delete_post_meta( $ticket->ID, '_ticket_attachment_id' );
		}
	}

    // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
	$comments = get_comments(
		array(
			'post_type'  => 'helpdesk_ticket',
			'number'     => 1,
			'date_query' => array(
				array(
					'column' => 'comment_date',
					'before' => $threshold_date,
				),
			),
			'meta_query' => array(
				array(
					'key'     => '_attachments',
					'compare' => 'EXISTS',
				),
			),
		)
	);
	$comments = is_array( $comments ) ? $comments : array();
	foreach ( $comments as $comment ) {
		if ( ! $comment instanceof WP_Comment ) {
			continue;
		}
		$atts = get_comment_meta( (int) $comment->comment_ID, '_attachments', true );
		if ( ! empty( $atts ) ) {
			if ( ! is_array( $atts ) ) {
				$atts = array( $atts );
			}
			foreach ( $atts as $url ) {
				if ( is_string( $url ) ) {
					swh_delete_file_by_url( $url );
				}
			}
			delete_comment_meta( (int) $comment->comment_ID, '_attachments' );
			/* translators: %d: number of days for retention */
			$new_content = $comment->comment_content . "\n\n*(" . sprintf( __( 'Attachments automatically purged after %d days', 'simple-wp-helpdesk' ), $days ) . ')*';
			wp_update_comment(
				array(
					'comment_ID'      => $comment->comment_ID,
					'comment_content' => $new_content,
				)
			);
		}
	}
	delete_transient( $lock_key );
}

/**
 * Processes the ticket retention cron event: permanently deletes old tickets and their files.
 *
 * @see swh_process_retention_tickets()
 */
add_action( 'swh_retention_tickets_event', 'swh_process_retention_tickets' );
/**
 * Permanently deletes tickets (and their files) older than the retention threshold.
 *
 * Processes 1 ticket per invocation. Uses a transient lock to prevent concurrent runs.
 *
 * @return void
 */
function swh_process_retention_tickets() {
	$days = swh_get_int_option( 'swh_retention_tickets_days', 0 );
	if ( $days <= 0 ) {
		return;
	}
	$lock_key = 'swh_lock_retention_tkt';
	if ( get_transient( $lock_key ) ) {
		return;
	}
	set_transient( $lock_key, 1, 5 * MINUTE_IN_SECONDS );
	$threshold_date = gmdate( 'Y-m-d H:i:s', time() - ( $days * DAY_IN_SECONDS ) );
	$tickets        = get_posts(
		array(
			'post_type'      => 'helpdesk_ticket',
			'posts_per_page' => 1,
			'date_query'     => array(
				array(
					'column' => 'post_modified',
					'before' => $threshold_date,
				),
			),
		)
	);
	foreach ( $tickets as $ticket ) {
		swh_delete_ticket_and_files( $ticket->ID );
	}
	delete_transient( $lock_key );
}

/**
 * Processes the SLA check cron event: detects breach/warn thresholds and sends digest alerts.
 *
 * @see swh_process_sla_check()
 */
add_action( 'swh_sla_check_event', 'swh_process_sla_check' );
/**
 * Checks open tickets against SLA warn and breach thresholds.
 *
 * Updates `_ticket_sla_status` to 'warn' or 'breach' on first detection.
 * Sends a digest email on first breach detection.
 * Uses a transient lock to prevent concurrent runs.
 *
 * Processes up to 20 tickets per run (micro-batched to avoid long-running cron jobs).
 * On sites with many open tickets, subsequent hourly runs will eventually process all.
 * The meta_query excludes tickets already marked 'breach', so each ticket is only alerted once.
 *
 * @since 3.0.0
 * @return void
 */
function swh_process_sla_check() {
	$warn_hours   = swh_get_int_option( 'swh_sla_warn_hours', 4 );
	$breach_hours = swh_get_int_option( 'swh_sla_breach_hours', 8 );
	if ( $warn_hours <= 0 && $breach_hours <= 0 ) {
		return;
	}
	$lock_key = 'swh_lock_sla';
	if ( get_transient( $lock_key ) ) {
		return;
	}
	set_transient( $lock_key, 1, 5 * MINUTE_IN_SECONDS );

	$open_statuses = array( 'Open', 'In Progress', 'Pending' );
	/**
	 * Filters the ticket statuses considered "open" for SLA purposes.
	 *
	 * @since 3.0.0
	 * @param string[] $open_statuses Array of status strings.
	 */
	$open_statuses  = apply_filters( 'swh_sla_open_statuses', $open_statuses );
	$now            = time();
	$breach_time    = $breach_hours > 0 ? $now - ( $breach_hours * HOUR_IN_SECONDS ) : 0;
	$warn_time      = $warn_hours > 0 ? $now - ( $warn_hours * HOUR_IN_SECONDS ) : 0;
	$breach_count   = 0;
	$newly_breached = array();

	// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
	$tickets = get_posts(
		array(
			'post_type'      => 'helpdesk_ticket',
			'posts_per_page' => 20,
			'meta_query'     => array(
				'relation' => 'AND',
				array(
					'key'     => '_ticket_status',
					'value'   => $open_statuses,
					'compare' => 'IN',
				),
				array(
					'relation' => 'OR',
					array(
						'key'     => '_ticket_sla_status',
						'compare' => 'NOT EXISTS',
					),
					array(
						'key'     => '_ticket_sla_status',
						'value'   => 'breach',
						'compare' => '!=',
					),
				),
			),
			'date_query'     => array(
				array(
					'column' => 'post_date',
					'before' => gmdate( 'Y-m-d H:i:s', $warn_time > 0 ? $warn_time : $breach_time ),
				),
			),
		)
	);

	if ( ! empty( $tickets ) ) {
		update_meta_cache( 'post', wp_list_pluck( $tickets, 'ID' ) );
	}
	foreach ( $tickets as $ticket ) {
		$post_date_ts  = strtotime( $ticket->post_date_gmt );
		$current_level = swh_get_string_meta( $ticket->ID, '_ticket_sla_status' );
		if ( $breach_time > 0 && $post_date_ts <= $breach_time ) {
			if ( 'breach' !== $current_level ) {
				update_post_meta( $ticket->ID, '_ticket_sla_status', 'breach' );
				$newly_breached[] = $ticket;
				++$breach_count;
			}
		} elseif ( $warn_time > 0 && $post_date_ts <= $warn_time && 'warn' !== $current_level ) {
			update_post_meta( $ticket->ID, '_ticket_sla_status', 'warn' );
		}
	}

	if ( ! empty( $newly_breached ) ) {
		$notify_email = swh_get_string_option( 'swh_sla_notify_email' );
		if ( ! $notify_email ) {
			$notify_email = swh_get_admin_email();
		}
		if ( is_email( $notify_email ) ) {
			$sla_lines = array();
			foreach ( $newly_breached as $breached_ticket ) {
				$uid         = swh_get_string_meta( $breached_ticket->ID, '_ticket_uid' );
				$title       = $breached_ticket->post_title;
				$url         = admin_url( 'post.php?post=' . $breached_ticket->ID . '&action=edit' );
				$sla_lines[] = ( $uid ? $uid . ': ' : '' ) . $title . ' — ' . $url;
			}
			$data = array(
				'sla_count' => $breach_count,
				'sla_list'  => implode( "\n", $sla_lines ),
			);
			swh_send_email( $notify_email, 'swh_em_admin_sla_breach_sub', 'swh_em_admin_sla_breach_body', $data );
		}
	}

	delete_transient( $lock_key );
}
